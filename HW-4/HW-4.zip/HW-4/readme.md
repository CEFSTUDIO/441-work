<h2><u>Homework 4 Read Me Response</u></h2>
<p>This was done in the course of a few hours in one day. It wasn't very hard- just a lot of referencing had to be done.
What was hard was the third JS project. That took about 2/3rds of the entire time it took to complete the assignment. I spent
awhile trying to debug and figure out what the problem was. Most of which were various scope issues. All in all not too
bad.</p>

<p>The first two barely took an hour to do. A small bit of referencing here and there. It was the last one that I struggled with.
A majority of my struggle was knowing how to do it in Java but having a hard time translating into JavaScript. Despite the fact
both are object orientated languages- they're very different. I kept writing strings of code in Java and not in JavaScript. The
third project took the most referencing. Difficult but not impossible.</p>
